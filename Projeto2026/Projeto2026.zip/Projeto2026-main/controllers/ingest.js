var fs = require('fs')
var path = require('path')
var crypto = require('crypto')
var AdmZip = require('adm-zip')

function checksumFile(filePath, algoritmo) {
  return new Promise(function(resolve, reject) {
    var hash = crypto.createHash(algoritmo)
    var input = fs.createReadStream(filePath)

    input.on('error', reject)
    input.on('data', function(chunk) { hash.update(chunk) })
    input.on('end', function() { resolve(hash.digest('hex')) })
  })
}

function parseManifest(text) {
  var linhas = text.split(/\r?\n/).filter(function(l) { return l.trim() !== '' })
  return linhas.map(function(l) {
    var partes = l.trim().split(/\s+/)
    return { checksum: partes[0], file: partes.slice(1).join(' ') }
  })
}

function readBagInfo(bagDir) {
  var info = {}
  var bagInfoPath = path.join(bagDir, 'bag-info.txt')

  if (fs.existsSync(bagInfoPath)) {
    var linhas = fs.readFileSync(bagInfoPath, 'utf8').split(/\r?\n/)
    linhas.forEach(function(l) {
      var i = l.indexOf(':')
      if (i > 0) {
        var key = l.substring(0, i).trim()
        var value = l.substring(i + 1).trim()
        info[key] = value
      }
    })
  }

  return info
}

async function validarBagIt(sipPath, aipDir) {
  var zip = new AdmZip(sipPath)
  zip.extractAllTo(aipDir, true)

  var bagitPath = path.join(aipDir, 'bagit.txt')
  if (!fs.existsSync(bagitPath)) {
    throw new Error('SIP invalido: falta o ficheiro bagit.txt')
  }

  var manifests = fs.readdirSync(aipDir).filter(function(f) {
    return f.match(/^manifest-(md5|sha1|sha256|sha512)\.txt$/)
  })

  if (manifests.length === 0) {
    throw new Error('SIP invalido: falta manifest-md5.txt ou manifest-sha256.txt')
  }

  var manifestFile = manifests[0]
  var algoritmo = manifestFile.replace('manifest-', '').replace('.txt', '')
  var manifestPath = path.join(aipDir, manifestFile)
  var entradas = parseManifest(fs.readFileSync(manifestPath, 'utf8'))
  var ficheiros = []

  for (var i = 0; i < entradas.length; i++) {
    var entrada = entradas[i]
    var dataPath = path.join(aipDir, entrada.file)

    if (!fs.existsSync(dataPath)) {
      throw new Error('SIP invalido: ficheiro em falta no manifesto: ' + entrada.file)
    }

    var checksum = await checksumFile(dataPath, algoritmo)
    if (checksum.toLowerCase() !== entrada.checksum.toLowerCase()) {
      throw new Error('SIP invalido: checksum incorreto para ' + entrada.file)
    }

    var stat = fs.statSync(dataPath)
    ficheiros.push({
      path: entrada.file,
      checksum: checksum,
      algoritmo: algoritmo,
      tamanho: stat.size
    })
  }

  return {
    manifestPath: manifestPath,
    manifestAlgoritmo: algoritmo,
    ficheiros: ficheiros,
    bagInfo: readBagInfo(aipDir)
  }
}

module.exports.validarBagIt = validarBagIt
