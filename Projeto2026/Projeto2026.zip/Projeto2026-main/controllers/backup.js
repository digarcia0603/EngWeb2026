var fs = require('fs')
var User = require('../models/user')
var Recurso = require('../models/recurso')

module.exports.exportar = async function() {
  var users = await User.find({}).lean().exec()
  var recursos = await Recurso.find({}).lean().exec()

  return {
    geradoEm: new Date(),
    users: users,
    recursos: recursos
  }
}

module.exports.importar = async function(filePath) {
  var texto = fs.readFileSync(filePath, 'utf8')
  var dados = JSON.parse(texto)
  var nUsers = 0
  var nRecursos = 0

  if (dados.users && Array.isArray(dados.users)) {
    for (var i = 0; i < dados.users.length; i++) {
      var u = dados.users[i]
      if (!u.username) continue

      var existeUser = await User.findOne({ username: u.username }).exec()
      if (existeUser) {
        delete u._id
        delete u.__v
        await User.updateOne({ username: u.username }, { $set: u }).exec()
      } else {
        await User.create(u)
      }
      nUsers++
    }
  }

  if (dados.recursos && Array.isArray(dados.recursos)) {
    for (var j = 0; j < dados.recursos.length; j++) {
      var r = dados.recursos[j]
      if (!r.id) continue

      var existeRecurso = await Recurso.findOne({ id: r.id }).exec()
      if (existeRecurso) {
        delete r._id
        delete r.__v
        await Recurso.updateOne({ id: r.id }, { $set: r }).exec()
      } else {
        await Recurso.create(r)
      }
      nRecursos++
    }
  }

  return { users: nUsers, recursos: nRecursos }
}
