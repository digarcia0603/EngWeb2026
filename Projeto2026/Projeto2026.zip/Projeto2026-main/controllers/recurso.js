var fs = require('fs')
var path = require('path')
var Recurso = require('../models/recurso')
var ingest = require('./ingest')

function splitList(valor) {
  if (!valor) return []
  if (Array.isArray(valor)) return valor
  return valor.split(',').map(function(v) { return v.trim() }).filter(function(v) { return v !== '' })
}

function novoId() {
  return 'REI' + Date.now()
}

function podeVerTudo(user) {
  return user && (user.nivel === 'administrador' || user.nivel === 'produtor')
}

function filtroVisivel(filtro, user) {
  filtro = filtro || {}

  if (podeVerTudo(user)) return filtro

  filtro.visibilidade = 'publico'
  filtro.estado = { $in: ['validado', 'publicado'] }
  return filtro
}

function procuraRegex(valor) {
  return new RegExp(valor, 'i')
}

function filtroPesquisa(query, user) {
  var filtro = {}

  if (query.q) {
    var exp = procuraRegex(query.q)
    filtro.$or = [
      { titulo: exp },
      { descricao: exp },
      { tipo: exp },
      { unidadeCurricular: exp },
      { autores: exp },
      { palavrasChave: exp }
    ]
  }

  if (query.tipo) filtro.tipo = procuraRegex(query.tipo)
  if (query.uc) filtro.unidadeCurricular = procuraRegex(query.uc)
  if (query.tag) filtro.palavrasChave = procuraRegex(query.tag)
  if (query.ano) filtro.dataCriacao = procuraRegex('^' + query.ano)

  return filtroVisivel(filtro, user)
}

module.exports.filtroPesquisa = filtroPesquisa

module.exports.list = function(filtro, user) {
  filtro = filtroVisivel(filtro, user)
  return Recurso.find(filtro)
    .populate('produtor', 'username nome email')
    .sort({ dataSubmissao: -1 })
    .exec()
}

module.exports.lookUp = function(id, user) {
  var filtro = filtroVisivel({ id: id }, user)
  return Recurso.findOne(filtro)
    .populate('produtor', 'username nome email')
    .exec()
}

module.exports.top3 = function(user) {
  return Recurso.aggregate([
    { $match: filtroVisivel({}, user) },
    { $addFields: { ranking: { $avg: '$ratings.valor' } } },
    { $sort: { ranking: -1, dataSubmissao: -1 } },
    { $limit: 3 }
  ])
}

module.exports.recentes = function(user) {
  return Recurso.find(filtroVisivel({}, user))
    .sort({ dataSubmissao: -1 })
    .limit(5)
    .populate('produtor', 'username nome')
    .exec()
}

module.exports.insert = async function(dados, file, user) {
  if (!file) throw new Error('Tem de submeter um ficheiro ZIP com o SIP.')

  var id = novoId()
  var aipBase = path.join(__dirname, '..', 'storage', 'aip', id)
  var bagDir = path.join(aipBase, 'bag')
  var sipDir = path.join(aipBase, 'original')
  fs.mkdirSync(bagDir, { recursive: true })
  fs.mkdirSync(sipDir, { recursive: true })

  var sipPath = path.join(sipDir, file.originalname)
  fs.renameSync(file.path, sipPath)

  var validacao = await ingest.validarBagIt(sipPath, bagDir)

  var estadoInicial = 'submetido'
  if (user.nivel === 'administrador') estadoInicial = dados.estado || 'publicado'

  var r = new Recurso({
    id: id,
    titulo: dados.titulo || validacao.bagInfo['Title'] || file.originalname,
    subtitulo: dados.subtitulo,
    descricao: dados.descricao || validacao.bagInfo['Description'],
    tipo: dados.tipo || validacao.bagInfo['Type'] || 'recurso educativo',
    formato: dados.formato || 'zip/bagit',
    idioma: dados.idioma || 'pt',
    autores: splitList(dados.autores || validacao.bagInfo['Authors']),
    palavrasChave: splitList(dados.palavrasChave || validacao.bagInfo['Keywords']),
    unidadeCurricular: dados.unidadeCurricular || validacao.bagInfo['UC'],
    dataCriacao: dados.dataCriacao || validacao.bagInfo['Date'],
    direitos: dados.direitos || validacao.bagInfo['Rights'],
    visibilidade: dados.visibilidade || 'publico',
    produtor: user._id,
    estado: estadoInicial,
    oais: {
      sipOriginalName: file.originalname,
      sipPath: sipPath,
      aipPath: aipBase,
      dipPath: sipPath,
      bagPath: bagDir,
      manifestPath: validacao.manifestPath,
      manifestAlgoritmo: validacao.manifestAlgoritmo,
      validadoEm: new Date(),
      ficheiros: validacao.ficheiros
    }
  })

  return r.save()
}

module.exports.update = function(id, dados, user) {
  var alteracoes = {
    titulo: dados.titulo,
    subtitulo: dados.subtitulo,
    descricao: dados.descricao,
    tipo: dados.tipo,
    formato: dados.formato,
    idioma: dados.idioma,
    autores: splitList(dados.autores),
    palavrasChave: splitList(dados.palavrasChave),
    unidadeCurricular: dados.unidadeCurricular,
    dataCriacao: dados.dataCriacao,
    direitos: dados.direitos,
    visibilidade: dados.visibilidade || 'publico'
  }

  if (user && user.nivel === 'administrador' && dados.estado) {
    alteracoes.estado = dados.estado
  }

  return Recurso.findOneAndUpdate({ id: id }, { $set: alteracoes }, { new: true }).exec()
}

module.exports.remove = function(id) {
  return Recurso.findOneAndDelete({ id: id }).exec()
}

module.exports.addPost = function(id, user, text) {
  return Recurso.findOneAndUpdate(
    filtroVisivel({ id: id }, user),
    { $push: { posts: { from: user.username, user: user._id, text: text } } },
    { new: true }
  ).exec()
}

module.exports.addComment = function(id, postId, user, text) {
  var filtro = filtroVisivel({ id: id, 'posts._id': postId }, user)
  return Recurso.findOneAndUpdate(
    filtro,
    { $push: { 'posts.$.comments': { from: user.username, user: user._id, text: text } } },
    { new: true }
  ).exec()
}

module.exports.addRating = async function(id, user, valor) {
  var r = await Recurso.findOne(filtroVisivel({ id: id }, user)).exec()
  if (!r) return null

  r.ratings = r.ratings.filter(function(rate) {
    return rate.user.toString() !== user._id.toString()
  })

  r.ratings.push({ user: user._id, valor: parseInt(valor, 10) })
  return r.save()
}
