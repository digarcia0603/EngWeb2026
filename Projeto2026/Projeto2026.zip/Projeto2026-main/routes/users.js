var express = require('express')
var router = express.Router()
var Users = require('../controllers/user')
var auth = require('../middlewares/auth')

router.get('/', auth.ensureAuth, auth.isAdmin, function(req, res, next) {
  Users.list()
    .then(function(dados) { res.render('users', { title: 'Utilizadores', users: dados }) })
    .catch(function(erro) { next(erro) })
})

router.post('/', auth.ensureAuth, auth.isAdmin, function(req, res, next) {
  Users.insert(req.body)
    .then(function() { res.redirect('/users') })
    .catch(function(erro) { next(erro) })
})

router.post('/:id/delete', auth.ensureAuth, auth.isAdmin, function(req, res, next) {
  Users.remove(req.params.id)
    .then(function() { res.redirect('/users') })
    .catch(function(erro) { next(erro) })
})

module.exports = router
