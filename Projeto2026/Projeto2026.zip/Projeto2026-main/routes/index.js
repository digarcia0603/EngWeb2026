var express = require('express')
var router = express.Router()
var Recursos = require('../controllers/recurso')

router.get('/', async function(req, res, next) {
  try {
    var recentes = await Recursos.recentes(req.session.user)
    var top = await Recursos.top3(req.session.user)
    res.render('index', { title: 'Recursos Educativos OAIS', recentes: recentes, top: top })
  } catch (e) {
    next(e)
  }
})

module.exports = router
