var express = require('express')
var router = express.Router()
var Users = require('../controllers/user')

router.get('/login', function(req, res) {
  res.render('login', { title: 'Login', erro: null })
})

router.post('/login', async function(req, res, next) {
  try {
    var user = await Users.login(req.body.username, req.body.password)
    if (!user) return res.render('login', { title: 'Login', erro: 'Credenciais invalidas.' })

    req.session.user = user
    res.redirect('/')
  } catch (e) {
    next(e)
  }
})

router.get('/register', function(req, res) {
  res.render('register', { title: 'Registo', erro: null })
})

router.post('/register', async function(req, res, next) {
  try {
    req.body.nivel = 'consumidor'
    await Users.insert(req.body)
    res.redirect('/auth/login')
  } catch (e) {
    res.render('register', { title: 'Registo', erro: e.message })
  }
})

router.get('/logout', function(req, res) {
  req.session.destroy(function() {
    res.redirect('/')
  })
})

module.exports = router
