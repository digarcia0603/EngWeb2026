var mongoose = require('mongoose')

var mongoDB = process.env.MONGO_URL || 'mongodb://127.0.0.1:27017/ewRecursos'

mongoose.connect(mongoDB)

var db = mongoose.connection

db.on('error', console.error.bind(console, 'Erro na ligacao ao MongoDB...'))
db.once('open', function() {
  console.log('Conexao ao MongoDB realizada com sucesso...')
})

module.exports = db
