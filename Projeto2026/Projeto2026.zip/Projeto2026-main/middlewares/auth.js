var Recurso = require('../models/recurso')

function ensureAuth(req, res, next) {
  if (req.session && req.session.user) return next()
  res.redirect('/auth/login')
}

function isAdmin(req, res, next) {
  if (req.session.user && req.session.user.nivel === 'administrador') return next()
  res.status(403).render('error', { message: 'Acesso reservado ao administrador.', error: {} })
}

function isProdutor(req, res, next) {
  if (req.session.user && ['administrador', 'produtor'].includes(req.session.user.nivel)) return next()
  res.status(403).render('error', { message: 'Acesso reservado a produtores.', error: {} })
}

async function canManageResource(req, res, next) {
  var r = await Recurso.findOne({ id: req.params.id }).exec()
  if (!r) return res.status(404).render('error', { message: 'Recurso inexistente.', error: {} })

  req.recurso = r
  if (req.session.user.nivel === 'administrador') return next()
  if (r.produtor.toString() === req.session.user._id.toString()) return next()

  res.status(403).render('error', { message: 'Nao tem permissao para alterar este recurso.', error: {} })
}

module.exports.ensureAuth = ensureAuth
module.exports.isAdmin = isAdmin
module.exports.isProdutor = isProdutor
module.exports.canManageResource = canManageResource
