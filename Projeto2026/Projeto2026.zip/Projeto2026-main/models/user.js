var mongoose = require('mongoose')

var UserSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  nome: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  nivel: {
    type: String,
    enum: ['administrador', 'produtor', 'consumidor'],
    default: 'consumidor'
  },
  ativo: { type: Boolean, default: true },
  filiacao: String,
  dataRegisto: { type: Date, default: Date.now },
  dataUltimoAcesso: Date
})

module.exports = mongoose.model('user', UserSchema)
