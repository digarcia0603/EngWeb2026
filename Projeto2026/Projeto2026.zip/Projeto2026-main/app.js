var createError = require('http-errors')
var express = require('express')
var path = require('path')
var cookieParser = require('cookie-parser')
var logger = require('morgan')
var session = require('express-session')

require('./config/db')

var indexRouter = require('./routes/index')
var authRouter = require('./routes/auth')
var recursosRouter = require('./routes/recursos')
var apiRecursosRouter = require('./routes/apiRecursos')
var usersRouter = require('./routes/users')
var backupRouter = require('./routes/backup')

var app = express()

app.set('views', path.join(__dirname, 'views'))
app.set('view engine', 'pug')

app.use(logger('dev'))
app.use(express.json())
app.use(express.urlencoded({ extended: false }))
app.use(cookieParser())
app.use(session({
  secret: process.env.SESSION_SECRET || 'segredo_de_aula',
  resave: false,
  saveUninitialized: false
}))

app.use(function(req, res, next) {
  res.locals.user = req.session.user
  next()
})

app.use(express.static(path.join(__dirname, 'public')))

app.use('/', indexRouter)
app.use('/auth', authRouter)
app.use('/recursos', recursosRouter)
app.use('/api/recursos', apiRecursosRouter)
app.use('/users', usersRouter)
app.use('/backup', backupRouter)

app.use(function(req, res, next) {
  next(createError(404))
})

app.use(function(err, req, res, next) {
  res.locals.message = err.message
  res.locals.error = req.app.get('env') === 'development' ? err : {}
  res.status(err.status || 500)
  res.render('error')
})

module.exports = app
